App = {
  web3Provider: null,
  contracts: {},
  account : '0X0',

  init: function() {
    
    return App.initWeb3();
  },

  initWeb3: async function() {


      if(window.ethereum){

        window.web3=new Web3(ethereum);
        try{
        
          await ethereum.enable();

          App.web3Provider=window.web3.currentProvider;
          console.log(App.web3Provider);
           
        }
        catch(error){
          alert("hi3");
          console.warn(error);
        }
      }
      else if(window.web3){
         
        App.web3Provider=web3.currentProvider;
        web3=new Web3(App.web3Provider);
      }



    return App.initContract();
  },

  initContract: function() {

    
   $.getJSON("Election.json",function(election){
    App.contracts.Election=TruffleContract(election);
    
    App.contracts.Election.setProvider(App.web3Provider);
    
    return App.render();
  });
  },

  

  render : function(){
    var electionInstance;
    var loader=$("#loader");
    var content=$("#content");

    loader.show();
    content.hide();
   

    web3.eth.getCoinbase(function(err,account){
      if(err===null){
        App.account=account;
        $("#accountAddress").html("Your account:"+account);
        }
      });
       App.contracts.Election.deployed().then(function(instance){
          
         electionInstance=instance;
         return electionInstance.candidatesCount(); 
       }).then(function(candidatesCount){
              
              var candidatesResults=$("#candidatesResults");
              candidatesResults.empty();
              var candidatesSelect=$("#candidatesSelect");
              candidatesSelect.empty();
              for(var i=1;i<=candidatesCount;i++)
              {
                electionInstance.candidates(i).then(function(candidate){
                  var id=candidate[0];
                  var name=candidate[1];
                  var voteCount=candidate[2];
                  var candidateTemplate="<tr><th>"+id+"</th><td>"+name+"</td><td>"+voteCount+"</td><tr>";
                  candidatesResults.append(candidateTemplate);
                  var candidateOption="<option value="+id+">"+name+"</option>";
                  candidatesSelect.append(candidateOption);

                });
              }

              
           
              return electionInstance.voters(App.account);
            }).then(function(hasVoted){
              if(hasVoted){
                  $('form').hide();
              }

              loader.hide();
              content.show();
            }).catch(function(error)
           {
            console.warn(error);
          });
     
      },


    castVote:function(){
    var candidateId=$('#candidatesSelect').val();
    App.contracts.Election.deployed().then(function(instance)
    {
      return instance.vote(candidateId,{from : App.account});
    }).then(function(result){
         App.render();
    }).catch(function(error)
    {
      console.error(error);
    });

    },

    renderTimer : function(){


      var electionInstance;
      var maxVotes=0;
      var win=$("#winner");
      
      var countDownDate = new Date("Nov 19, 2018 15:53:00").getTime();
      var x = setInterval(function() {
        var now = new Date().getTime();
        var distance = countDownDate - now;

        if (distance < 0) {
    clearInterval(x);
      document.getElementById("timer").innerHTML = "Expired";
      document.getElementById("timer").style.color="red";
      $('form').hide();
      App.contracts.Election.deployed().then(function(instance){
          electionInstance=instance;
          return electionInstance.candidatesCount();
      }).then(function(CandidatesCount){


            for(var i=1;i<=CandidatesCount;i++)
            {
              electionInstance.candidates(i).then(function(cand){
              if(cand[2]>maxVotes){

                maxVotes=cand[2];
                
                 win.html("Winner is  "+cand[1]);

                }
              });
              
            }
           
            
            
      });

   }
     else
        {
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);
        document.getElementById("timer").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";
     if(minutes<1)
           {
            document.getElementById("timer").style.color="red";
           }
         }

      },1000);


    }



    
    };
  



$(function() {
  $(window).load(function() {
    App.renderTimer();
    App.init();
    
  });
});
